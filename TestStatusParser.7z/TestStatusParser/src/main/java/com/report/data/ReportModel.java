package com.report.data;

public class ReportModel {

    private String team;
    private ReportBranchModel reportBranchModel;
}
