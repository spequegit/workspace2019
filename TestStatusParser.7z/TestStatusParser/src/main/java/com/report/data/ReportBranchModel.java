package com.report.data;

public class ReportBranchModel {
}
