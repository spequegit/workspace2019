package com.report.data;

public enum RecordType {
    DEVELOPMENT,OTHER
}
